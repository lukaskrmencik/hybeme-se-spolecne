<h1>Dobrý den, <?php echo e($adminName); ?>!</h1>
<p>Uživatel <?php echo e($userName); ?> žádá o přezkoumání podvodu.</p>
<p>Zpráva od uživatele: </p>
<p><?php echo e($userMessage); ?></p>
<p>Podvod je možné přezkoumat v administrátorském panelu.</p>
<p>Děkujeme, aplikace Hýbeme se společně</p>

<?php /**PATH /var/www/html/resources/views/emails/cheatDenyRequest.blade.php ENDPATH**/ ?>