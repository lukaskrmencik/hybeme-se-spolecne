<?php

namespace App\Http\Controllers;

use App\Models\Cheat;
use App\Models\Place;
use App\Models\Visit;
use App\Models\VisitsPhoto;
use App\Services\AntiCheatService;
use App\Services\ImageModerationService;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class VisitController extends Controller
{
    use AuthorizesRequests;

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $this->authorize('viewAny', Visit::class);

        $perPage = (int) $request->input('per_page', config('pagination.per_page_default'));
        if (
            $perPage < config('pagination.per_page_min') ||
            $perPage > config('pagination.per_page_max')
        ){
            $perPage = config('pagination.per_page_default');
        }

        $query = Visit::query()->with(['user', 'place', 'sport', 'photos']);

        if ($request->filled('search')) {
            $searchTerm = $request->input('search');

            $query->where(function ($q) use ($searchTerm) {
                $q->whereHas('user', function ($userQuery) use ($searchTerm) {
                    $userQuery->where('name', 'ILIKE', '%' . $searchTerm . '%');
                })
                ->orWhereHas('place', function ($placeQuery) use ($searchTerm) {
                    $placeQuery->where('name', 'ILIKE', '%' . $searchTerm . '%');
                })
                ->orWhereHas('sport', function ($sportQuery) use ($searchTerm) {
                    $sportQuery->where('name', 'ILIKE', '%' . $searchTerm . '%');
                });
            });
        }
        $visits = $query->paginate($perPage);

        return response()->pagination($visits);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, AntiCheatService $antiCheatService)
    {
        $this->authorize('create', Visit::class);

        $user = $request->user();

        $validatedData = $request->validate([
            'place_id' => 'required|exists:places,id',
            'sport_id' => 'required|exists:sports,id',
            'is_combination' => 'required|boolean',
            'timestamp' => 'required|date',
        ]);

        if($validatedData['is_combination'] === true && $user->visitsCombinations()->count() === 0) {
            $validatedData['is_combination'] = false;
        }

        $antiCheatResult = $antiCheatService->checkNewVisit($validatedData, $user);
        $validatedData['user_id'] = $user->id;

        $cheatNote = null;

        if ($antiCheatResult->isCheating) {
            if($antiCheatResult->solution === "not_save") {

                return response()->error($antiCheatResult->cheatMessage, 400);

            } elseif ($antiCheatResult->solution === "not_combination") {

                $cheatNote = $antiCheatResult->cheatMessage;
                $validatedData['is_combination'] = false;
            }
        }

        $defaultReward = Place::findOrFail($validatedData['place_id'])->default_reward;

        if($validatedData['is_combination'] === true) {

            $lastVisit = $user->visitsCombinations()->last();

            $reward = calc_combination_reward($user, $validatedData['sport_id'], $validatedData['place_id'], $defaultReward, $lastVisit);

        } else {
            $reward = $defaultReward;
        }

        $validatedData['reward'] = $reward;

        $visit = Visit::create($validatedData);

        if($cheatNote) {
            Cheat::create([
                'visit_id' => $visit->id,
                'visit_id_2' => $user->visitsCombinations()->last()->id,
                'user_message' => null,
                'is_denied' => false,
                'cheat_description' => $cheatNote,
            ]);
        }

        return response()->success([
            'id' => $visit->id,
            'place_id' => $visit->place_id,
            'sport_id' => $visit->sport_id,
            'user_id' => $visit->user_id,
            'reward' => $visit->reward,
            'is_combination' => $visit->is_combination,
            'timestamp' => $visit->timestamp,
            'cheat_note' => $cheatNote,
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Visit $visit)
    {
        $this->authorize('view', $visit);

        $visit->load(['user', 'place', 'sport', 'photos']);

        return response()->success([
            'id' => $visit->id,
            'place_id' => $visit->place_id,
            'sport_id' => $visit->sport_id,
            'user_id' => $visit->user_id,
            'place' => $visit->place,
            'sport' => $visit->sport,
            'photos' => $visit->photos,
            'user' => $visit->user,
            'reward' => $visit->reward,
            'is_combination' => $visit->is_combination,
            'timestamp' => $visit->timestamp,
        ]);
    }

    public function uploadPhoto(Request $request, Visit $visit, ImageModerationService $imageModerationService)
    {
        $this->authorize('uploadPhoto', $visit);

        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        $file = $request->file('photo');

        if (!$imageModerationService->isSafe($file)) {
            return response()->error('Fotka nesplňuje podmínky aplikace.', 422);
        }

        $filename = uniqid() . '.' . $file->getClientOriginalExtension();

        Storage::disk('public')->putFileAs('visits_photos', $file, $filename);

        $path = 'visits_photos/' . $filename;

        $publicUrl = url('storage/' . $path);

        $visitsPhoto = VisitsPhoto::create([
            'visit_id' => $visit->id,
            'photo_url' => $publicUrl,
        ]);

        return response()->success([
            'id' => $visitsPhoto->id,
            'visit_id' => $visitsPhoto->visit_id,
            'photo_url' => $visitsPhoto->photo_url,
        ], 201);
    }

    public function deletePhoto(Request $request, VisitsPhoto $visitsPhoto){

        $this->authorize('deletePhoto', $visitsPhoto->visit);

        $path = str_replace(url('storage/'), '', $visitsPhoto->photo_url);
        if (Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }

        $visitsPhoto->delete();

        return response()->success([
            'message' => 'Fotka byla úspěšně smazána.',
        ], 200);
    }
}
