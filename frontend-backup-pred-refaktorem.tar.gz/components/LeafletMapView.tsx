import React, { forwardRef, memo, useImperativeHandle, useMemo, useRef } from 'react';
import { Platform, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { Place } from '../types/place';

export interface PlaceStatus {
  inactive: boolean;
  reason: string | null;
  reward: number | null;
}

export interface LeafletMapHandle {
  updateUserLocation(lat: number, lng: number, accuracy: number | null): void;
  updatePlaceStatus(statusMap: Record<number, PlaceStatus>): void;
  updateActivePlace(placeId: number | null, inRange: boolean): void;
}

interface LeafletMapProps {
  places: Place[];
  defaultLat: number;
  defaultLng: number;
  visitRadiusMeters: number;
  onReady?: () => void;
}

function escapeScript(value: string): string {
  return value
    .replace(/&/g, '\\u0026')
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e');
}

const MAP_HTML = `
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <style>
    html, body, #map { margin:0; padding:0; height:100%; width:100%; }
    body { background:#e2e8f0; font-family:-apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    .leaflet-container { font: inherit; }
    .place-marker { background: transparent; border: none; }
    .place-pin { position:relative; width:40px; height:46px; }
    .place-pin .dot {
      position:absolute; left:11px; bottom:3px; width:18px; height:18px;
      border-radius: 50% 50% 50% 0; transform: rotate(-45deg);
      background:#10b981; border:2.5px solid #fff;
      box-shadow:0 2px 6px rgba(0,0,0,.35);
    }
    .place-pin.inactive { opacity: 0.6; }
    .place-pin.inactive .dot { background:#cbd5e1; border-color:#f8fafc; box-shadow:none; }
    .place-pin.inactive .reward { display:none; }
    .place-pin .reward {
      position:absolute; top:0; left:50%; transform:translateX(-50%);
      background:#059669; color:#fff; font-size:11px; font-weight:800;
      padding:2px 7px; border-radius:999px; white-space:nowrap;
      box-shadow:0 2px 4px rgba(0,0,0,.3);
    }
    .leaflet-popup-content-wrapper { border-radius:14px; }
    .leaflet-popup-content { font-weight:600; color:#0f172a; margin:10px 14px; }
  </style>
</head>
<body>
  <div id="map"></div>
  <script>
    var PLACES = __PLACES__;
    var VISIT_RADIUS = __RADIUS__;
    var placeMarkers = {};
    var activeZone = null;
    var userMarker = null;
    var userAcc = null;
    var activePlaceId = null;
    var castLine = null;

    var map = L.map('map', { zoomControl: true }).setView([__LAT__, __LNG__], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    function placeIcon(id) {
      var html = '<div class="place-pin" id="pin-' + id + '"><span class="reward">&middot;</span><div class="dot"></div></div>';
      return L.divIcon({ className: 'place-marker', html: html, iconSize: [40, 46], iconAnchor: [20, 44] });
    }

    function escHtml(v) {
      return String(v).replace(/[&<>"']/g, function (m) {
        return {
          '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[m];
      });
    }

    function pinOf(mk) {
      var el = mk.getElement();
      return el ? (el.querySelector('.place-pin') || el) : null;
    }

    function applyStatus(id, s) {
      var mk = placeMarkers[id];
      if (!mk) return;
      var pin = pinOf(mk);
      if (!pin) return;
      var inactive = !!(s && s.inactive);
      pin.classList.toggle('inactive', inactive);
      var name = mk.options.placeName;
      var html;
      if (inactive) {
        var reason = (s && s.reason)
          ? '<span style="color:#94a3b8;font-weight:600;">' + escHtml(s.reason) + '</span>'
          : '<span style="color:#94a3b8;font-weight:600;">Momentálně nedostupné</span>';
        html = '<b>' + escHtml(name) + '</b><br>' + reason;
      } else {
        var pts = (s && s.reward != null) ? s.reward : null;
        var badge = pin.querySelector('.reward');
        if (badge) badge.textContent = (pts == null) ? '\u00b7' : '+' + pts;
        html = '<b>' + escHtml(name) + '</b>' + ((pts == null) ? '' : '<br><b>+' + pts + ' bodů</b>');
      }
      mk.unbindPopup().bindPopup(html);
    }

    function updatePlaceStatus(statusMap) {
      Object.keys(statusMap || {}).forEach(function (k) {
        applyStatus(k, statusMap[k] || { inactive: false, reason: null, reward: null });
      });
    }

    function updateActivePlace(placeId, inRange) {
      activePlaceId = (placeId == null ? null : String(placeId));
      if (activeZone) {
        map.removeLayer(activeZone);
        activeZone = null;
      }
      var mk = placeMarkers[activePlaceId];
      if (mk && inRange && VISIT_RADIUS > 0) {
        activeZone = L.circle(mk.getLatLng(), {
          radius: VISIT_RADIUS, color: '#10b981', weight: 1.5,
          dashArray: '4 5', fillColor: '#10b981', fillOpacity: 0.08, interactive: false
        }).addTo(map);
      }
      updateCastLine();
    }

    function updateCastLine() {
      if (castLine) {
        map.removeLayer(castLine);
        castLine = null;
      }
      var mk = placeMarkers[activePlaceId];
      if (!mk || !userMarker) return;
      castLine = L.polyline([userMarker.getLatLng(), mk.getLatLng()], {
        color: '#10b981', weight: 2, opacity: 0.7,
        dashArray: '6 8', interactive: false
      }).addTo(map);
    }

    function updateUserLocation(lat, lng, accuracy) {
      if (!userMarker) {
        userMarker = L.circleMarker([lat, lng], {
          radius: 7, color: '#1e40af', weight: 2,
          fillColor: '#3b82f6', fillOpacity: 0.95
        }).addTo(map);
        userAcc = L.circle([lat, lng], {
          radius: accuracy || 30, color: '#60a5fa', weight: 1,
          fillColor: '#60a5fa', fillOpacity: 0.12, interactive: false
        }).addTo(map);
        map.setView([lat, lng], Math.max(map.getZoom(), 15));
      } else {
        userMarker.setLatLng([lat, lng]);
        userAcc.setLatLng([lat, lng]);
        if (accuracy) userAcc.setRadius(accuracy);
      }
      updateCastLine();
    }

    function renderPlaces() {
      PLACES.forEach(function (p) {
        var mk = L.marker([p.lat, p.lng], { icon: placeIcon(p.id), placeName: p.name }).addTo(map);
        placeMarkers[p.id] = mk;
        applyStatus(p.id, null);
      });
    }

    window.updateUserLocation = updateUserLocation;
    window.updatePlaceStatus = updatePlaceStatus;
    window.updateActivePlace = updateActivePlace;

    window.addEventListener('message', function (event) {
      var data = event.data;
      if (!data || typeof data !== 'object') return;
      if (data.type === 'UPDATE_LOCATION') updateUserLocation(data.lat, data.lng, data.accuracy);
      else if (data.type === 'UPDATE_STATUS') updatePlaceStatus(data.statusMap);
      else if (data.type === 'UPDATE_ACTIVE') updateActivePlace(data.placeId, data.inRange);
    });

    renderPlaces();
  </script>
</body>
</html>
`;

export const LeafletMapView = memo(
  forwardRef<LeafletMapHandle, LeafletMapProps>(function LeafletMapView(
    { places, defaultLat, defaultLng, visitRadiusMeters, onReady },
    ref
  ) {
    const webViewRef = useRef<WebView | null>(null);
    const iframeRef = useRef<HTMLIFrameElement | null>(null);
    const readyRef = useRef(false);
    const pendingRef = useRef<Array<() => void>>([]);
    const onReadyRef = useRef(onReady);

    const mapHtml = useMemo(() => {
      const markers = places.map((p) => {
        const [lng, lat] = p.coordinates.coordinates;
        return { id: p.id, name: p.name, lat, lng };
      });
      return MAP_HTML
        .replace('__PLACES__', escapeScript(JSON.stringify(markers)))
        .replace('__RADIUS__', String(visitRadiusMeters))
        .replace('__LAT__', String(defaultLat))
        .replace('__LNG__', String(defaultLng));
    }, [places, defaultLat, defaultLng, visitRadiusMeters]);

    const handleLoad = () => {
      readyRef.current = true;
      pendingRef.current.splice(0).forEach((fn) => fn());
      if (onReadyRef.current) onReadyRef.current();
    };

    useImperativeHandle(
      ref,
      () => {
        const post = (nativeJs: string, message: Record<string, unknown>) => {
          const run = () => {
            if (Platform.OS === 'web') {
              iframeRef.current?.contentWindow?.postMessage(message, '*');
            } else {
              webViewRef.current?.injectJavaScript(nativeJs);
            }
          };
          if (readyRef.current) {
            run();
          } else {
            pendingRef.current.push(run);
          }
        };

        return {
          updateUserLocation: (lat, lng, accuracy) =>
            post(
              `if(window.updateUserLocation){window.updateUserLocation(${lat},${lng},${
                accuracy == null ? 'null' : accuracy
              });} true;`,
              { type: 'UPDATE_LOCATION', lat, lng, accuracy }
            ),
          updatePlaceStatus: (statusMap) =>
            post(
              `if(window.updatePlaceStatus){window.updatePlaceStatus(${JSON.stringify(statusMap)});} true;`,
              { type: 'UPDATE_STATUS', statusMap }
            ),
          updateActivePlace: (placeId, inRange) =>
            post(
              `if(window.updateActivePlace){window.updateActivePlace(${placeId == null ? 'null' : placeId},${
                inRange ? 'true' : 'false'
              });} true;`,
              { type: 'UPDATE_ACTIVE', placeId: placeId == null ? null : placeId, inRange }
            ),
        };
      },
      []
    );

    return (
      <View style={{ flex: 1 }}>
        {Platform.OS === 'web' ? (
          <iframe
            ref={iframeRef}
            srcDoc={mapHtml}
            onLoad={handleLoad}
            title="map"
            style={{ width: '100%', height: '100%', border: 'none' }}
          />
        ) : (
          <WebView
            ref={webViewRef}
            originWhitelist={['*']}
            source={{ html: mapHtml }}
            javaScriptEnabled
            domStorageEnabled
            onLoad={handleLoad}
            style={{ flex: 1 }}
          />
        )}
      </View>
    );
  })
);