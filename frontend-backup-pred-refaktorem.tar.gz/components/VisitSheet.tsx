import React, { forwardRef, useCallback, useImperativeHandle, useMemo, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import BottomSheet, { BottomSheetView, BottomSheetBackdrop } from '@gorhom/bottom-sheet';
import Checkbox from 'expo-checkbox';
import { SportChips } from './SportChips';
import { Place } from '../types/place';
import { Sport } from '../types/sport';
import { Visit } from '../types/user';
import { getCombinationLevel, getCombinationMultiplier } from '../utils/rewardMath';

export interface VisitSheetHandle {
  expand: () => void;
  close: () => void;
}

interface VisitSheetProps {
  place: Place | null;
  distance: number | null;
  sports: Sport[];
  selectedSportId: number | undefined;
  onSelectSport: (id: number) => void;
  lastVisit: Visit | null;
  showCombination: boolean;
  isCombination: boolean;
  onToggleCombination: (v: boolean) => void;
  allowed: boolean;
  blockReason: string | null;
  comboNote: string | null;
  reward: number;
  isSaving: boolean;
  onSave: () => void;
  onChange: (index: number) => void;
}

export const VisitSheet = forwardRef<VisitSheetHandle, VisitSheetProps>(
  (
    {
      place,
      distance,
      sports,
      selectedSportId,
      onSelectSport,
      lastVisit,
      showCombination,
      isCombination,
      onToggleCombination,
      allowed,
      blockReason,
      comboNote,
      reward,
      isSaving,
      onSave,
      onChange,
    },
    ref
  ) => {
    const snapPoints = useMemo(() => ['58%'], []);
    const sheetRef = useRef<BottomSheet>(null);

    useImperativeHandle(
      ref,
      () => ({
        expand: () => sheetRef.current?.expand(),
        close: () => sheetRef.current?.close(),
      }),
      []
    );

    const level = lastVisit ? getCombinationLevel(lastVisit) : 0;
    const selectedSport = sports.find((s) => s.id === selectedSportId);
    const mult = selectedSport ? getCombinationMultiplier(selectedSport, level) : 1;

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop {...props} disappearsOnIndex={-1} appearsOnIndex={0} opacity={0.45} />
      ),
      []
    );

    return (
      <BottomSheet
        ref={sheetRef}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backdropComponent={renderBackdrop}
        onChange={onChange}
        backgroundStyle={styles.sheet}
        handleIndicatorStyle={styles.handle}
      >
        <BottomSheetView style={styles.content}>
          {place && (
            <>
              <Text style={styles.title} numberOfLines={2}>
                {place.name}
              </Text>
              <View style={styles.distanceChip}>
                <Text style={styles.distanceText}>
                  {distance != null ? `${Math.round(distance)} m od cíle` : 'Jsi v dosahu'}
                </Text>
              </View>

              <Text style={styles.label}>Sport</Text>
              <SportChips sports={sports} selectedId={selectedSportId} onSelect={onSelectSport} />

              {showCombination && lastVisit && (
                <TouchableOpacity
                  style={styles.checkboxRow}
                  activeOpacity={0.7}
                  onPress={() => onToggleCombination(!isCombination)}
                >
                  <Checkbox
                    value={isCombination}
                    onValueChange={onToggleCombination}
                    color={isCombination ? '#10b981' : undefined}
                    style={styles.checkbox}
                  />
                  <View style={styles.checkboxTextContainer}>
                    <Text style={styles.checkboxLabel} numberOfLines={2}>
                      Dopravil ses sem sportem {selectedSport?.name ?? '…'}?
                    </Text>
                    <Text style={styles.checkboxSubLabel} numberOfLines={2}>
                      {comboNote
                        ? 'Neuzná se – kombinace by neprošla pravidly.'
                        : `Kombinace z místa ${lastVisit.place.name} · úroveň ${level} · ×${mult}`}
                    </Text>
                  </View>
                </TouchableOpacity>
              )}

              {isCombination && comboNote && (
                <View style={styles.noteBox}>
                  <Text style={styles.noteText}>{comboNote}</Text>
                </View>
              )}

              <View style={styles.rewardBox}>
                <Text style={[styles.rewardValue, reward > place.default_reward && styles.rewardValueBoosted]}>
                  +{reward}
                </Text>
                <Text style={styles.rewardLabel}>bodů za tuto návštěvu</Text>
              </View>

              {!allowed && blockReason && (
                <View style={styles.blockBox}>
                  <Text style={styles.blockText}>{blockReason}</Text>
                </View>
              )}

              <TouchableOpacity
                style={[styles.saveButton, !allowed && styles.saveButtonDisabled]}
                onPress={onSave}
                disabled={!allowed || isSaving}
              >
                {isSaving ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.saveButtonText}>
                    {allowed ? 'Uložit návštěvu' : 'Návštěva není povolena'}
                  </Text>
                )}
              </TouchableOpacity>
            </>
          )}
        </BottomSheetView>
      </BottomSheet>
    );
  }
);

const styles = StyleSheet.create({
  sheet: {
    backgroundColor: '#ffffff',
    borderRadius: 28,
  },
  handle: {
    backgroundColor: '#cbd5e1',
    width: 46,
    height: 5,
  },
  content: {
    flex: 1,
    paddingHorizontal: 22,
    paddingBottom: 24,
  },
  title: {
    fontSize: 26,
    fontWeight: '900',
    color: '#0f172a',
    textAlign: 'center',
    marginTop: 6,
  },
  distanceChip: {
    alignSelf: 'center',
    backgroundColor: '#d1fae5',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    marginTop: 8,
    marginBottom: 16,
  },
  distanceText: {
    color: '#047857',
    fontSize: 13,
    fontWeight: '700',
  },
  label: {
    fontSize: 13,
    fontWeight: '700',
    color: '#64748b',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 8,
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    marginTop: 18,
  },
  checkbox: {
    width: 24,
    height: 24,
    marginRight: 14,
    borderRadius: 7,
  },
  checkboxTextContainer: {
    flex: 1,
  },
  checkboxLabel: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0f172a',
  },
  checkboxSubLabel: {
    fontSize: 13,
    color: '#64748b',
    marginTop: 3,
  },
  rewardBox: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
  },
  rewardValue: {
    fontSize: 60,
    fontWeight: '900',
    color: '#059669',
    lineHeight: 66,
  },
  rewardValueBoosted: {
    color: '#10b981',
  },
  rewardLabel: {
    fontSize: 13,
    color: '#64748b',
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  saveButton: {
    backgroundColor: '#059669',
    width: '100%',
    height: 58,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#059669',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
  },
  saveButtonDisabled: {
    opacity: 0.7,
  },
  blockBox: {
    backgroundColor: '#fef2f2',
    borderColor: '#fecaca',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  blockText: {
    color: '#b91c1c',
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  noteBox: {
    backgroundColor: '#fffbeb',
    borderColor: '#fde68a',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 8,
  },
  noteText: {
    color: '#92400e',
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '800',
  },
});