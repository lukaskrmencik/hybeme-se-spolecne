import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { colors } from '../utils/theme';

interface AvatarProps {
    name: string;
    url?: string | null;
    size?: number;
}

export const Avatar = ({ name, url, size = 44 }: AvatarProps) => {
    const initials = name
        .split(/\s+/)
        .map((p) => p[0])
        .filter(Boolean)
        .slice(0, 2)
        .join('')
        .toUpperCase();

    const radius = size / 2;

    if (url) {
        return (
            <Image
                source={{ uri: url }}
                style={{ width: size, height: size, borderRadius: radius, backgroundColor: colors.primaryBg }}
            />
        );
    }

    return (
        <View
            style={[
                styles.fallback,
                {
                    width: size,
                    height: size,
                    borderRadius: radius,
                },
            ]}
        >
            <Text style={[styles.initials, { fontSize: size * 0.38 }]}>{initials || '?'}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    fallback: {
        backgroundColor: colors.primaryLight,
        alignItems: 'center',
        justifyContent: 'center',
    },
    initials: {
        color: colors.primaryDark,
        fontWeight: '900',
    },
});