export function parseVisitTime(value: string): number {
  if (typeof value !== 'string' || value.length === 0) return NaN;

  const iso = Date.parse(value);
  if (!isNaN(iso)) return iso;

  const czech = /^(\d{2})\.(\d{2})\.(\d{4})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/.exec(value.trim());
  if (czech) {
    const [, d, m, y, h, min, s] = czech;
    return Date.UTC(Number(y), Number(m) - 1, Number(d), Number(h), Number(min), s ? Number(s) : 0);
  }

  const mysql = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/.exec(value.trim());
  if (mysql) {
    const [, y, mo, d, h, min, s] = mysql;
    return Date.UTC(Number(y), Number(mo) - 1, Number(d), Number(h), Number(min), s ? Number(s) : 0);
  }

  return NaN;
}

export function formatVisitTime(value: string): string {
  const ms = parseVisitTime(value);
  if (isNaN(ms)) return value;
  return new Date(ms).toLocaleString('cs-CZ');
}