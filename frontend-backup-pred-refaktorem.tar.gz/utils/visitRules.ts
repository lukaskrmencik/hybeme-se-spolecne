import { Visit } from '../types/user';
import { Place } from '../types/place';
import { parseVisitTime } from './dates';

export interface VisitEligibility {
  allowed: boolean;
  reason: string | null;
  kind: 'combination_repeat' | 'cooldown' | 'min_interval' | null;
}

const COOLDOWN_HOURS = parseInt(process.env.EXPO_PUBLIC_PLACE_COOLDOWN_HOURS || '72', 10);
const MIN_INTERVAL_MINUTES = parseInt(process.env.EXPO_PUBLIC_MIN_VISIT_INTERVAL_MINUTES || '5', 10);

function sortNewestFirst(visits: Visit[]): Visit[] {
  return [...visits].sort(
    (a, b) => parseVisitTime(b.timestamp) - parseVisitTime(a.timestamp)
  );
}

export function checkVisitEligibility(
  place: Place,
  lastVisit: Visit | null,
  isCombination: boolean,
  visits: Visit[]
): VisitEligibility {
  if (!lastVisit || visits.length === 0) {
    return { allowed: true, reason: null, kind: null };
  }

  const ordered = sortNewestFirst(visits);
  const now = Date.now();

  if (isCombination) {
    for (const v of ordered) {
      if (v.place_id === place.id) {
        return {
          allowed: false,
          kind: 'combination_repeat',
          reason: 'Toto místo už je součástí aktuální kombinace.',
        };
      }
      if (v.combination_order === 0) {
        break;
      }
    }
    return { allowed: true, reason: null, kind: null };
  }

  for (const v of ordered) {
    if (v.place_id === place.id) {
      const hoursDiff = (now - parseVisitTime(v.timestamp)) / 3600000;
      if (hoursDiff < COOLDOWN_HOURS) {
        return {
          allowed: false,
          kind: 'cooldown',
          reason: `Toto místo jsi navštívil v posledních ${COOLDOWN_HOURS} hodinách (cooldown).`,
        };
      }
      break;
    }
  }

  const newest = ordered[0];
  const minutesDiff = (now - parseVisitTime(newest.timestamp)) / 60000;
  if (minutesDiff < MIN_INTERVAL_MINUTES) {
    return {
      allowed: false,
      kind: 'min_interval',
      reason: `Mezi návštěvami musí být alespoň ${MIN_INTERVAL_MINUTES} minut.`,
    };
  }

  return { allowed: true, reason: null, kind: null };
}