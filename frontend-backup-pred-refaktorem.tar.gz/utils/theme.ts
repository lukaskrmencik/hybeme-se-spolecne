export const colors = {
  primary: '#059669',
  primaryDark: '#047857',
  primaryLight: '#d1fae5',
  primaryBg: '#ecfdf5',
  background: '#f8fafc',
  surface: '#ffffff',
  border: '#e2e8f0',
  text: '#0f172a',
  muted: '#64748b',
  inactive: '#94a3b8',
  accent: '#f59e0b',
  accentBg: '#fef3c7',
  accentText: '#92400e',
  danger: '#ef4444',
  dangerBg: '#fef2f2',
  dangerText: '#b91c1c',
  white: '#ffffff',
};

export const radius = {
  sm: 10,
  md: 16,
  lg: 22,
  full: 999,
};

export const shadows = {
  card: {
    shadowColor: '#000000',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  button: {
    shadowColor: '#000000',
    shadowOpacity: 0.18,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 5,
  },
};

export const typography = {
  sectionTitle: {
    fontSize: 13,
    fontWeight: '800' as const,
    color: colors.muted,
    textTransform: 'uppercase' as const,
    letterSpacing: 0.8,
  },
};