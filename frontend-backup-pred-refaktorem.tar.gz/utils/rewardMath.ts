import { getDistanceInMeters } from './distance';
import { parseVisitTime } from './dates';
import { Sport } from '../types/sport';
import { Place } from '../types/place';
import { Visit } from '../types/user';

const POINTS_PER_KM = parseFloat(process.env.EXPO_PUBLIC_POINTS_PER_KM || '10');
const ROUTING_COEFFICIENT = parseFloat(process.env.EXPO_PUBLIC_ROUTING_COEFFICIENT || '1.23');

export enum CombinationReason {
  NONE = 'none',
  NO_PREVIOUS_VISIT = 'no_previous_visit',
  SPORT_MISMATCH = 'sport_mismatch',
  TOO_SLOW = 'too_slow',
  TOO_FAST = 'too_fast',
}

export interface CombinationPrediction {
  valid: boolean;
  reason: CombinationReason;
  speed: number;
  message: string;
}

export function getCombinationLevel(lastVisit: Visit | null): number {
  if (!lastVisit) return 0;
  const order = lastVisit.combination_order != null ? lastVisit.combination_order : 0;
  return Math.min(order + 1, 4);
}

export function getCombinationMultiplier(sport: Sport, level: number): number {
  if (level >= 4) return sport.comb_mult_4;
  if (level === 3) return sport.comb_mult_3;
  if (level === 2) return sport.comb_mult_2;
  if (level === 1) return sport.comb_mult_1;
  return 1;
}

export function calculateCombinationReward(
  currentPlace: Place,
  sport: Sport,
  lastVisit: Visit | null,
  isCombinationChecked: boolean
): number {
  if (!isCombinationChecked || !lastVisit) {
    return currentPlace.default_reward;
  }

  const combMultLevel = getCombinationLevel(lastVisit);
  const combMult = getCombinationMultiplier(sport, combMultLevel);

  const [currLng, currLat] = currentPlace.coordinates.coordinates;
  const [lastLng, lastLat] = lastVisit.place.coordinates.coordinates;

  const distanceInMeters = getDistanceInMeters(currLat, currLng, lastLat, lastLng);
  const distanceInKilometers = distanceInMeters / 1000;

  const reward = Math.floor(
    (currentPlace.default_reward + distanceInKilometers * POINTS_PER_KM) * combMult
  );

  return reward;
}

export function predictCombinationSpeed(
  currentPlace: Place,
  sport: Sport,
  lastVisit: Visit | null,
  nowMs: number
): CombinationPrediction | null {
  if (!lastVisit || !lastVisit.place) {
    return {
      valid: false,
      reason: CombinationReason.NO_PREVIOUS_VISIT,
      speed: 0,
      message: 'Není předchozí návštěva.',
    };
  }

  const elapsedSeconds = (nowMs - parseVisitTime(lastVisit.timestamp)) / 1000;

  const lastSportId = lastVisit.sport_id ?? lastVisit.sport?.id ?? null;
  if (lastSportId != null && sport.id !== lastSportId) {
    return {
      valid: false,
      reason: CombinationReason.SPORT_MISMATCH,
      speed: 0,
      message: `Kombinace vyžaduje stejný sport jako předchozí návštěva (${
        lastVisit.sport?.name ?? 'jiný sport'
      }).`,
    };
  }

  if (elapsedSeconds <= 0) {
    return {
      valid: false,
      reason: CombinationReason.TOO_FAST,
      speed: 0,
      message: 'Příliš rychlý přesun v čase.',
    };
  }

  const [currLng, currLat] = currentPlace.coordinates.coordinates;
  const [lastLng, lastLat] = lastVisit.place.coordinates.coordinates;
  const distanceKilometers =
    (getDistanceInMeters(currLat, currLng, lastLat, lastLng) * ROUTING_COEFFICIENT) / 1000;

  const speed = distanceKilometers / (elapsedSeconds / 3600);

  if (speed < sport.min_speed) {
    return {
      valid: false,
      reason: CombinationReason.TOO_SLOW,
      speed,
      message: `Příliš nízká rychlost (${speed.toFixed(1)} km/h, minimální ${sport.min_speed} km/h).`,
    };
  }

  if (speed > sport.max_speed) {
    return {
      valid: false,
      reason: CombinationReason.TOO_FAST,
      speed,
      message: `Příliš vysoká rychlost (${speed.toFixed(1)} km/h, maximální ${sport.max_speed} km/h).`,
    };
  }

  return { valid: true, reason: CombinationReason.NONE, speed, message: '' };
}