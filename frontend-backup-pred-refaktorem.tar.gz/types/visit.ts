export interface VisitSubmission {
  place_id: number;
  sport_id: number;
  is_combination: boolean;
  timestamp: string;
}

export interface QueuedVisit extends VisitSubmission {
  id: string;
  clientId: number;
  reward: number;
  place_name?: string;
  sport_name?: string;
  createdAt: number;
  reason?: string;
}