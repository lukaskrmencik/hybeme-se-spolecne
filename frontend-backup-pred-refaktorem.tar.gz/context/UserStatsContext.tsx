import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, AppState, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { jwtDecode } from 'jwt-decode';
import { apiFetch } from '../services/api';
import { getToken } from '../services/storage';
import { useAuth } from './AuthContext';
import { UserProfile, Visit } from '../types/user';
import { Place } from '../types/place';
import { Sport } from '../types/sport';
import { flushQueue, getPendingCount, onChange as onQueueChange } from '../services/offlineQueue';
import { checkVisitEligibility, VisitEligibility } from '../utils/visitRules';
import { parseVisitTime } from '../utils/dates';

const STORAGE_KEY_USER = 'cached_user_profile';

export interface OptimisticVisitInput {
  clientId: number;
  place: Place;
  sport: Sport;
  reward: number;
  is_combination: boolean;
  timestamp: string;
}

interface UserStatsContextValue {
  profile: UserProfile | null;
  lastVisit: Visit | null;
  loading: boolean;
  pendingCount: number;
  refreshStats: (force?: boolean) => Promise<void>;
  applyOptimisticVisit: (input: OptimisticVisitInput) => void;
  revertOptimisticVisit: (clientId: number) => void;
  flushNow: () => Promise<void>;
  checkEligibility: (place: Place, isCombination: boolean) => VisitEligibility;
}

const UserStatsContext = createContext<UserStatsContextValue | undefined>(undefined);

export function UserStatsProvider({ children }: { children: React.ReactNode }) {
  const { token } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [lastVisit, setLastVisit] = useState<Visit | null>(null);
  const [loading, setLoading] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);

  const profileRef = useRef<UserProfile | null>(null);
  const lastVisitRef = useRef<Visit | null>(null);
  const flushNowRef = useRef<(() => Promise<void>) | null>(null);

  const persist = useCallback((value: UserProfile) => {
    AsyncStorage.setItem(STORAGE_KEY_USER, JSON.stringify(value)).catch(() => {});
  }, []);

  const findLastVisit = useCallback((visits: Visit[] | undefined): Visit | null => {
    if (!visits || visits.length === 0) return null;
    return [...visits].sort(
      (a, b) => parseVisitTime(b.timestamp) - parseVisitTime(a.timestamp)
    )[0];
  }, []);

  const checkEligibility = useCallback(
    (place: Place, isCombination: boolean): VisitEligibility =>
      checkVisitEligibility(place, lastVisitRef.current, isCombination, profileRef.current?.visitsCombinations ?? []),
    []
  );

  const applyVisit = useCallback(
    (input: OptimisticVisitInput) => {
      const prev = profileRef.current;
      if (!prev) return;
      const last = lastVisitRef.current;
      const synthetic: Visit = {
        id: input.clientId,
        reward: input.reward,
        user_id: prev.id,
        place_id: input.place.id,
        sport_id: input.sport.id,
        is_combination: input.is_combination,
        timestamp: input.timestamp,
        combination_order:
          input.is_combination
            ? last && last.combination_order != null
              ? last.combination_order + 1
              : 1
            : null,
        place: input.place,
        sport: input.sport,
      };
      const next: UserProfile = {
        ...prev,
        totalPoints: prev.totalPoints + input.reward,
        visitsCombinations: [synthetic, ...prev.visitsCombinations],
      };
      profileRef.current = next;
      lastVisitRef.current = synthetic;
      setProfile(next);
      setLastVisit(synthetic);
      persist(next);
    },
    [persist]
  );

  const revertVisit = useCallback(
    (clientId: number) => {
      const prev = profileRef.current;
      if (!prev) return;
      const target = prev.visitsCombinations.find((v) => v.id === clientId);
      if (!target) return;
      const next: UserProfile = {
        ...prev,
        totalPoints: Math.max(0, prev.totalPoints - target.reward),
        visitsCombinations: prev.visitsCombinations.filter((v) => v.id !== clientId),
      };
      profileRef.current = next;
      const last = next.visitsCombinations.length ? findLastVisit(next.visitsCombinations) : null;
      lastVisitRef.current = last;
      setProfile(next);
      setLastVisit(last);
      persist(next);
    },
    [findLastVisit, persist]
  );

  const refreshPendingCount = useCallback(async () => {
    setPendingCount(await getPendingCount());
  }, []);

  const fetchUserStats = useCallback(
    async (force = false) => {
      try {
        setLoading(true);
        const authToken = await getToken();
        if (!authToken) {
          setLoading(false);
          return;
        }

        const decoded: any = jwtDecode(authToken);
        const userId = decoded.sub || decoded.user_id;

        if (!force) {
          const raw = await AsyncStorage.getItem(STORAGE_KEY_USER);
          if (raw) {
            const parsed: UserProfile = JSON.parse(raw);
            profileRef.current = parsed;
            setProfile(parsed);
            const last = findLastVisit(parsed.visitsCombinations);
            lastVisitRef.current = last;
            setLastVisit(last);
          }
        }

        const res = await apiFetch(`users/${userId}`);
        const fresh: UserProfile = res.data;
        profileRef.current = fresh;
        setProfile(fresh);
        const last = findLastVisit(fresh.visitsCombinations);
        lastVisitRef.current = last;
        setLastVisit(last);
        persist(fresh);
      } catch (err) {
        if (!profileRef.current) {
          const raw = await AsyncStorage.getItem(STORAGE_KEY_USER);
          if (raw) {
            const parsed: UserProfile = JSON.parse(raw);
            profileRef.current = parsed;
            setProfile(parsed);
            const last = findLastVisit(parsed.visitsCombinations);
            lastVisitRef.current = last;
            setLastVisit(last);
          }
        }
      } finally {
        setLoading(false);
      }
    },
    [findLastVisit, persist]
  );

  useEffect(() => {
    if (!token) {
      profileRef.current = null;
      lastVisitRef.current = null;
      setProfile(null);
      setLastVisit(null);
      AsyncStorage.removeItem(STORAGE_KEY_USER);
      setLoading(false);
    } else {
      fetchUserStats();
    }
  }, [token, fetchUserStats]);

  useEffect(() => {
    refreshPendingCount();
    return onQueueChange(refreshPendingCount);
  }, [refreshPendingCount]);

  useEffect(() => {
    let active = true;

    const flush = async () => {
      const messages: string[] = [];
      const result = await flushQueue({
        onDropped: (entry) => {
          if (entry.clientId) {
            revertVisit(entry.clientId);
          }
          if (entry.reason) {
            messages.push(`${entry.place_name || 'Návštěva'}: ${entry.reason}`);
          }
        },
      });
      if (!active) return;
      refreshPendingCount();
      if (result && (result.synced > 0 || result.dropped > 0)) {
        await fetchUserStats(true);
      }
      if (messages.length > 0) {
        Alert.alert('Návštěva zamítnuta', messages.join('\n'));
      }
    };

    flushNowRef.current = flush;

    const bootTimer = setTimeout(() => {
      flush();
    }, 2500);
    const interval = setInterval(() => {
      flush();
    }, 30000);

    const appSub = AppState.addEventListener('change', (state) => {
      if (state === 'active') flush();
    });

    let onlineHandler: (() => void) | undefined;
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      onlineHandler = () => flush();
      window.addEventListener('online', onlineHandler);
    }

    return () => {
      active = false;
      clearTimeout(bootTimer);
      clearInterval(interval);
      appSub.remove();
      if (onlineHandler) {
        window.removeEventListener('online', onlineHandler);
      }
    };
  }, [fetchUserStats, revertVisit, refreshPendingCount, persist]);

  const flushNow = useCallback(async () => {
    if (flushNowRef.current) {
      await flushNowRef.current();
    }
  }, []);

  const value = useMemo(
    () => ({
      profile,
      lastVisit,
      loading,
      pendingCount,
      refreshStats: fetchUserStats,
      applyOptimisticVisit: applyVisit,
      revertOptimisticVisit: revertVisit,
      flushNow,
      checkEligibility,
    }),
    [profile, lastVisit, loading, pendingCount, fetchUserStats, applyVisit, revertVisit, flushNow, checkEligibility]
  );

  return <UserStatsContext.Provider value={value}>{children}</UserStatsContext.Provider>;
}

export function useUserStats(): UserStatsContextValue {
  const ctx = useContext(UserStatsContext);
  if (!ctx) {
    throw new Error('useUserStats musí být použit uvnitř UserStatsProvideru');
  }
  return ctx;
}