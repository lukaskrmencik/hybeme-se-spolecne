import { useState, useCallback, useEffect } from 'react';
import { apiFetch } from '../services/api';

export interface LeaderboardEntry {
    id: number;
    name: string;
    avatar_url: string | null;
    total_points: number;
    rank: number;
}

interface LeaderboardResponse {
    leaderboard: LeaderboardEntry[];
    current_user: LeaderboardEntry | null;
}

export function useLeaderboard() {
    const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
    const [currentUser, setCurrentUser] = useState<LeaderboardEntry | null>(null);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const fetchBoard = useCallback(async (force = false) => {
        if (force) {
            setRefreshing(true);
        } else {
            setLoading(true);
        }
        try {
            const res: LeaderboardResponse = await apiFetch('users/leaderboard');
            setEntries(res.leaderboard ?? []);
            setCurrentUser(res.current_user ?? null);
            setError(null);
        } catch (err: any) {
            setError(err?.error_message || 'Nepodařilo se načíst žebříček.');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => {
        fetchBoard();
    }, [fetchBoard]);

    return { entries, currentUser, loading, refreshing, error, refresh: () => fetchBoard(true) };
}