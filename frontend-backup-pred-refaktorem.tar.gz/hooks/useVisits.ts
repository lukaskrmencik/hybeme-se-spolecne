import { apiFetch } from '../services/api';
import { Place } from '../types/place';
import { Sport } from '../types/sport';
import { QueuedVisit } from '../types/visit';
import { enqueueVisit } from '../services/offlineQueue';

export interface SaveVisitInput {
  place: Place;
  sport: Sport;
  isCombination: boolean;
  timestamp: string;
  reward: number;
  clientId: number;
}

export type SaveVisitResult =
  | { kind: 'success'; data: any }
  | { kind: 'offline' };

const LOCAL_ID_PREFIX = 'visit-';

export function useVisits() {
  const saveVisit = async (input: SaveVisitInput): Promise<SaveVisitResult> => {
    const payload = {
      place_id: input.place.id,
      sport_id: input.sport.id,
      is_combination: input.isCombination,
      timestamp: input.timestamp,
    };

    try {
      const res = await apiFetch('visits', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      return { kind: 'success', data: res.data };
    } catch (err: any) {
      const code = err && err.status_code;
      if (typeof code === 'number' && code >= 400 && code < 500 && code !== 401) {
        const message = err.error_message || 'Návštěva byla zamítnuta jako neplatná.';
        const error: any = new Error(message);
        error.status_code = code;
        throw error;
      }

      const entry: QueuedVisit = {
        id: `${LOCAL_ID_PREFIX}${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        clientId: input.clientId,
        place_id: input.place.id,
        sport_id: input.sport.id,
        is_combination: input.isCombination,
        timestamp: input.timestamp,
        reward: input.reward,
        place_name: input.place.name,
        sport_name: input.sport.name,
        createdAt: Date.now(),
      };

      try {
        await enqueueVisit(entry);
        return { kind: 'offline' };
      } catch {
        const error: any = new Error('Nepodařilo se uložit návštěvu ani do lokální paměti.');
        error.status_code = 500;
        throw error;
      }
    }
  };

  return { saveVisit };
}