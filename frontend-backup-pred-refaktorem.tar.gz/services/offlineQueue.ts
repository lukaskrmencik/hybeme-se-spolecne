import AsyncStorage from '@react-native-async-storage/async-storage';
import { apiFetch } from './api';
import { QueuedVisit } from '../types/visit';

const QUEUE_KEY = 'offline_visits_queue';

let flushing = false;
const listeners = new Set<() => void>();

function emit(): void {
  listeners.forEach((fn) => fn());
}

export function onChange(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export async function getQueuedVisits(): Promise<QueuedVisit[]> {
  try {
    const raw = await AsyncStorage.getItem(QUEUE_KEY);
    return raw ? (JSON.parse(raw) as QueuedVisit[]) : [];
  } catch {
    return [];
  }
}

export async function getPendingCount(): Promise<number> {
  return (await getQueuedVisits()).length;
}

export async function enqueueVisit(entry: QueuedVisit): Promise<void> {
  const queue = await getQueuedVisits();
  queue.push(entry);
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  emit();
}

export async function removeQueuedVisit(id: string): Promise<void> {
  const queue = await getQueuedVisits();
  const next = queue.filter((q) => q.id !== id);
  if (next.length !== queue.length) {
    await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(next));
    emit();
  }
}

function toPayload(entry: QueuedVisit) {
  return {
    place_id: entry.place_id,
    sport_id: entry.sport_id,
    is_combination: entry.is_combination,
    timestamp: entry.timestamp,
  };
}

export interface FlushOptions {
  onDropped?: (entry: QueuedVisit) => void;
}

export interface FlushResult {
  synced: number;
  dropped: number;
}

export async function flushQueue(options: FlushOptions = {}): Promise<FlushResult | null> {
  if (flushing) return null;

  const queue = await getQueuedVisits();
  if (queue.length === 0) return { synced: 0, dropped: 0 };

  flushing = true;
  let synced = 0;
  let dropped = 0;
  const remaining: QueuedVisit[] = [];

  try {
    let pending: QueuedVisit[] = [...queue];
    while (pending.length > 0) {
      const entry = pending[0];
      try {
        await apiFetch('visits', {
          method: 'POST',
          body: JSON.stringify(toPayload(entry)),
        });
        synced++;
        pending.shift();
      } catch (err: any) {
        const code = err && err.status_code;
        if (typeof code === 'number' && code >= 400 && code < 500 && code !== 401) {
          if (options.onDropped) {
            options.onDropped({ ...entry, reason: err.error_message || 'Návštěva byla zamítnuta.' });
          }
          dropped++;
          pending.shift();
        } else {
          remaining.push(...pending);
          pending = [];
        }
      }
    }

    await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(remaining));
    if (synced > 0 || dropped > 0) {
      emit();
    }
    return { synced, dropped };
  } finally {
    flushing = false;
  }
}