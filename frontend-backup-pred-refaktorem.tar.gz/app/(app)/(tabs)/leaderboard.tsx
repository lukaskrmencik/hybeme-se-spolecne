import React from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useUserStats } from '../../../context/UserStatsContext';
import { useLeaderboard, LeaderboardEntry } from '../../../hooks/useLeaderboard';
import { Avatar } from '../../../components/Avatar';
import { colors, radius, shadows, typography } from '../../../utils/theme';

const MEDAL: Record<number, { bg: string; color: string }> = {
    1: { bg: '#fef3c7', color: '#b45309' },
    2: { bg: '#e2e8f0', color: '#475569' },
    3: { bg: '#fed7aa', color: '#9a3412' },
};

function RankBadge({ rank }: { rank: number }) {
    const medal = MEDAL[rank];
    if (medal) {
        return (
            <View style={[styles.rankBadge, { backgroundColor: medal.bg }]}>
                <Text style={[styles.rankText, { color: medal.color }]}>{rank}</Text>
            </View>
        );
    }
    return (
        <View style={[styles.rankBadge, styles.rankBadgePlain]}>
            <Text style={styles.rankTextPlain}>{rank}</Text>
        </View>
    );
}

export default function LeaderboardScreen() {
    const { entries, currentUser, loading, refreshing, error, refresh } = useLeaderboard();
    const { profile } = useUserStats();

    if (loading && entries.length === 0) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    const currentUserId = profile?.id ?? (currentUser?.id ?? null);
    const inTop = entries.some((e) => e.id === currentUserId);

    const renderRow = ({ item, index }: { item: LeaderboardEntry; index: number }) => {
        const isMe = item.id === currentUserId;
        return (
            <View style={[styles.row, isMe && styles.rowMe]}>
                <View style={styles.rankWrap}>
                    <RankBadge rank={item.rank ?? index + 1} />
                </View>
                <Avatar name={item.name} url={item.avatar_url} />
                <View style={styles.rowBody}>
                    <Text style={[styles.rowName, isMe && styles.rowNameMe]} numberOfLines={1}>
                        {item.name}
                    </Text>
                    {isMe && (
                        <View style={styles.meTag}>
                            <Text style={styles.meTagText}>ty</Text>
                        </View>
                    )}
                </View>
                <View style={styles.pointsWrap}>
                    <Text style={styles.rowPoints}>{item.total_points}</Text>
                    <Text style={styles.pointsLabel}>bodů</Text>
                </View>
            </View>
        );
    };

    return (
        <FlatList
            style={styles.container}
            contentContainerStyle={styles.content}
            data={entries}
            keyExtractor={(item) => `${item.id}`}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.primary} />}
            ListHeaderComponent={
                <>
                    <View style={styles.heroCard}>
                        <Ionicons name="podium" size={24} color="#a7f3d0" />
                        <View style={styles.heroBody}>
                            <Text style={styles.heroTitle}>Žebříček bodů</Text>
                            <Text style={styles.heroSubtitle}>Nejlepší uživatelé podle bodů</Text>
                        </View>
                    </View>

                    {currentUser && !inTop && (
                        <View style={styles.myRankCard}>
                            <View style={styles.myRankIcon}>
                                <Ionicons name="location" size={18} color={colors.primaryDark} />
                            </View>
                            <View style={styles.myRankBody}>
                                <Text style={styles.myRankLabel}>Tvoje pozice</Text>
                                <Text style={styles.myRankValue}>
                                    {currentUser.rank ? `${currentUser.rank}.` : '—'} místo · {currentUser.total_points} bodů
                                </Text>
                            </View>
                            <Avatar name={currentUser.name} url={currentUser.avatar_url} />
                        </View>
                    )}

                    {entries.length > 0 && <Text style={styles.sectionTitle}>Nejlepší hráči</Text>}
                </>
            }
            renderItem={renderRow}
            ListEmptyComponent={
                <View style={styles.emptyBox}>
                    <Ionicons name="trophy-outline" size={40} color={colors.inactive} />
                    <Text style={styles.emptyText}>{error ? 'Žebříček se nepodařilo načíst.' : 'Žebříček je zatím prázdný.'}</Text>
                    {error && (
                        <TouchableOpacity style={styles.retryButton} onPress={refresh}>
                            <Text style={styles.retryText}>Zkusit znovu</Text>
                        </TouchableOpacity>
                    )}
                </View>
            }
        />
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    content: { padding: 16, paddingBottom: 40 },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background },
    heroCard: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        backgroundColor: colors.primary,
        borderRadius: radius.md,
        paddingVertical: 12,
        paddingHorizontal: 16,
        marginBottom: 16,
        ...shadows.card,
    },
    heroBody: { flex: 1 },
    heroTitle: { color: '#fff', fontSize: 16, fontWeight: '900' },
    heroSubtitle: { color: '#a7f3d0', fontSize: 12, fontWeight: '600', marginTop: 1 },
    myRankCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.primaryBg,
        borderRadius: radius.md,
        padding: 14,
        borderWidth: 1,
        borderColor: colors.primaryLight,
        marginBottom: 20,
        gap: 12,
    },
    myRankIcon: {
        width: 38,
        height: 38,
        borderRadius: 19,
        backgroundColor: colors.primaryLight,
        alignItems: 'center',
        justifyContent: 'center',
    },
    myRankBody: { flex: 1 },
    myRankLabel: { fontSize: 12, fontWeight: '800', color: colors.primaryDark, textTransform: 'uppercase', letterSpacing: 0.6 },
    myRankValue: { fontSize: 15, fontWeight: '800', color: colors.text, marginTop: 2 },
    sectionTitle: { ...typography.sectionTitle, marginBottom: 10, marginTop: 4 },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        paddingVertical: 12,
        paddingHorizontal: 12,
        marginBottom: 8,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.card,
    },
    rowMe: {
        backgroundColor: colors.primaryLight,
        borderColor: colors.primary,
    },
    rankWrap: { width: 34 },
    rankBadge: {
        width: 30,
        height: 30,
        borderRadius: 15,
        alignItems: 'center',
        justifyContent: 'center',
    },
    rankBadgePlain: {
        backgroundColor: '#f1f5f9',
    },
    rankText: { fontSize: 14, fontWeight: '900' },
    rankTextPlain: { fontSize: 14, fontWeight: '800', color: colors.muted },
    rowBody: { flex: 1, marginLeft: 12 },
    rowName: { fontSize: 15, fontWeight: '700', color: colors.text },
    rowNameMe: { color: colors.primaryDark },
    meTag: {
        alignSelf: 'flex-start',
        backgroundColor: colors.primary,
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: radius.sm - 2,
        marginTop: 3,
        overflow: 'hidden',
    },
    meTagText: { color: '#fff', fontSize: 11, fontWeight: '800' },
    pointsWrap: { alignItems: 'flex-end' },
    rowPoints: { fontSize: 17, fontWeight: '900', color: colors.primary },
    pointsLabel: { fontSize: 11, color: colors.muted, fontWeight: '700', textTransform: 'uppercase' },
    emptyBox: {
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        padding: 32,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: colors.border,
        gap: 8,
    },
    emptyText: { color: colors.text, fontWeight: '700', fontSize: 15, textAlign: 'center' },
    retryButton: {
        backgroundColor: colors.primary,
        paddingHorizontal: 18,
        paddingVertical: 10,
        borderRadius: radius.sm + 4,
        ...shadows.button,
    },
    retryText: { color: '#fff', fontWeight: '800' },
});