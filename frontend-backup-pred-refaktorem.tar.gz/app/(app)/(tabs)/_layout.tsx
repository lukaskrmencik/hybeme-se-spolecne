import { Ionicons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { useUserStats } from '../../../context/UserStatsContext';
import { colors } from '../../../utils/theme';

function PointsBadge() {
    const { profile, pendingCount } = useUserStats();
    const points = profile?.totalPoints ?? 0;

    return (
        <View style={styles.badgeGroup}>
            {pendingCount > 0 && (
                <View style={styles.pendingBadge}>
                    <Ionicons name="cloud-offline-outline" size={13} color={colors.accentText} />
                    <Text style={styles.pendingText}>{pendingCount}</Text>
                </View>
            )}
            <View style={styles.pointsBadge}>
                <Ionicons name="star" size={14} color={colors.accent} />
                <Text style={styles.pointsText}>{points} b.</Text>
            </View>
        </View>
    );
}

const TAB_ICONS: Record<string, { active: any; inactive: any }> = {
    map: { active: 'map', inactive: 'map-outline' },
    visits: { active: 'footsteps', inactive: 'footsteps-outline' },
    leaderboard: { active: 'podium', inactive: 'podium-outline' },
    account: { active: 'person-circle', inactive: 'person-circle-outline' },
};

export default function TabsLayout() {
    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: colors.primary,
                tabBarInactiveTintColor: colors.inactive,
                tabBarStyle: styles.tabBar,
                tabBarItemStyle: styles.tabBarItem,
                tabBarLabelStyle: styles.tabBarLabel,
                tabBarHideOnKeyboard: true,
                headerStyle: styles.header,
                headerTitleStyle: styles.headerTitle,
                headerTitleAlign: 'center',
                headerShadowVisible: false,
                headerRight: () => (
                    <View style={{ marginRight: 16 }}>
                        <PointsBadge />
                    </View>
                ),
            }}
        >
            <Tabs.Screen
                name="map"
                options={{
                    title: 'Mapa',
                    tabBarIcon: ({ color, size, focused }) => (
                        <Ionicons
                            name={focused ? TAB_ICONS.map.active : TAB_ICONS.map.inactive}
                            size={size}
                            color={color}
                        />
                    ),
                }}
            />
            <Tabs.Screen
                name="visits"
                options={{
                    title: 'Návštěvy',
                    tabBarIcon: ({ color, size, focused }) => (
                        <Ionicons
                            name={focused ? TAB_ICONS.visits.active : TAB_ICONS.visits.inactive}
                            size={size}
                            color={color}
                        />
                    ),
                }}
            />
            <Tabs.Screen
                name="leaderboard"
                options={{
                    title: 'Žebříček',
                    tabBarIcon: ({ color, size, focused }) => (
                        <Ionicons
                            name={focused ? TAB_ICONS.leaderboard.active : TAB_ICONS.leaderboard.inactive}
                            size={size}
                            color={color}
                        />
                    ),
                }}
            />
            <Tabs.Screen
                name="account"
                options={{
                    title: 'Účet',
                    tabBarIcon: ({ color, size, focused }) => (
                        <Ionicons
                            name={focused ? TAB_ICONS.account.active : TAB_ICONS.account.inactive}
                            size={size}
                            color={color}
                        />
                    ),
                }}
            />
        </Tabs>
    );
}

const styles = StyleSheet.create({
    badgeGroup: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    pendingBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: colors.accentBg,
        paddingHorizontal: 9,
        paddingVertical: 4,
        borderRadius: 12,
    },
    pendingText: {
        fontWeight: '800',
        color: colors.accentText,
        fontSize: 13,
    },
    pointsBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        backgroundColor: colors.primaryBg,
        paddingHorizontal: 11,
        paddingVertical: 5,
        borderRadius: 999,
    },
    pointsText: {
        fontWeight: '800',
        color: colors.primaryDark,
        fontSize: 13,
    },
    header: {
        backgroundColor: colors.surface,
    },
    headerTitle: {
        color: colors.text,
        fontWeight: '800',
        fontSize: 17,
    },
    tabBar: {
        backgroundColor: colors.surface,
        borderTopWidth: 1,
        borderTopColor: colors.border,
        height: Platform.OS === 'web' ? 64 : 60,
        paddingTop: 6,
    },
    tabBarItem: {
        paddingVertical: 2,
    },
    tabBarLabel: {
        fontSize: 11,
        fontWeight: '700',
    },
});