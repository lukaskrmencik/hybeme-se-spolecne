import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity, Alert } from 'react-native';
import * as Location from 'expo-location';

import { usePlaces } from '../../../hooks/usePlaces';
import { useSports } from '../../../hooks/useSports';
import { useVisits } from '../../../hooks/useVisits';
import { useUserStats } from '../../../context/UserStatsContext';
import { LeafletMapView, LeafletMapHandle, PlaceStatus } from '../../../components/LeafletMapView';
import { SportChips } from '../../../components/SportChips';
import { VisitSheet, VisitSheetHandle } from '../../../components/VisitSheet';
import { getDistanceInMeters } from '../../../utils/distance';
import { calculateCombinationReward, predictCombinationSpeed } from '../../../utils/rewardMath';
import { Place } from '../../../types/place';
import { VisitEligibility } from '../../../utils/visitRules';

const VISIT_RADIUS = parseInt(process.env.EXPO_PUBLIC_VISIT_RADIUS_METERS || '50', 10);
const DEFAULT_LAT = parseFloat(process.env.EXPO_PUBLIC_DEFAULT_LAT || '50.293056');
const DEFAULT_LNG = parseFloat(process.env.EXPO_PUBLIC_DEFAULT_LNG || '14.829167');

interface GpsState {
  lat: number;
  lng: number;
  accuracy: number | null;
}

export default function MapScreen() {
  const { places, loading: loadingPlaces, error } = usePlaces();
  const { sports, loading: loadingSports } = useSports();
  const {
    lastVisit,
    loading: loadingStats,
    refreshStats,
    applyOptimisticVisit,
    revertOptimisticVisit,
    checkEligibility,
  } = useUserStats();
  const { saveVisit } = useVisits();

  const [gps, setGps] = useState<GpsState | null>(null);
  const [closestPlace, setClosestPlace] = useState<{ place: Place; distance: number } | null>(null);
  const [selectedSportId, setSelectedSportId] = useState<number | undefined>(undefined);
  const [isCombination, setIsCombination] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [, setRefreshTick] = useState(0);
  const [mapReady, setMapReady] = useState(false);

  const mapRef = useRef<LeafletMapHandle>(null);
  const sheetRef = useRef<VisitSheetHandle>(null);

  const eligibilityMap = useMemo(() => {
    const map: Record<number, { nonComb: VisitEligibility; combo: VisitEligibility }> = {};
    for (const p of places) {
      map[p.id] = {
        nonComb: checkEligibility(p, false),
        combo: lastVisit ? checkEligibility(p, true) : { allowed: true, reason: null, kind: null },
      };
    }
    return map;
  }, [places, lastVisit, checkEligibility]);

  const placeStatus = useMemo(() => {
    const sport = sports.find((s) => s.id === selectedSportId) ?? null;
    const map: Record<number, PlaceStatus> = {};
    for (const p of places) {
      const e = eligibilityMap[p.id];
      const eligible = (e?.nonComb.allowed ?? true) || (e?.combo.allowed ?? false);
      if (eligible) {
        map[p.id] = {
          inactive: false,
          reason: null,
          reward: lastVisit && sport && lastVisit.sport_id === sport.id
            ? calculateCombinationReward(p, sport, lastVisit, true)
            : p.default_reward,
        };
      } else {
        map[p.id] = {
          inactive: true,
          reason: e?.nonComb.reason ?? e?.combo.reason ?? null,
          reward: null,
        };
      }
    }
    return map;
  }, [places, sports, selectedSportId, lastVisit, eligibilityMap]);

  const isWithinRadius = closestPlace ? closestPlace.distance <= VISIT_RADIUS : false;

  const eligNonComb = closestPlace ? eligibilityMap[closestPlace.place.id]?.nonComb ?? null : null;
  const eligCombo = closestPlace ? eligibilityMap[closestPlace.place.id]?.combo ?? null : null;
  const currentElig = isCombination ? eligCombo : eligNonComb;

  const selectedSport = selectedSportId !== undefined ? sports.find((s) => s.id === selectedSportId) : undefined;
  const comboPrediction =
    closestPlace && lastVisit && selectedSport
      ? predictCombinationSpeed(closestPlace.place, selectedSport, lastVisit, Date.now())
      : null;
  const comboPathValid = comboPrediction ? comboPrediction.valid : true;
  const canVisitCurrent =
    (currentElig?.allowed ?? true) && (!isCombination || comboPathValid);

  const comboCanMatchSport =
    closestPlace && isCombination && lastVisit && selectedSport &&
    lastVisit.sport_id === selectedSport.id;

  const calculatedReward = comboCanMatchSport
    ? calculateCombinationReward(closestPlace.place, selectedSport!, lastVisit, true)
    : (closestPlace?.place.default_reward ?? 0);

  const comboNote =
    isCombination && lastVisit && comboPrediction && !comboPrediction.valid
      ? comboPrediction.message
      : null;
  const blockReason = canVisitCurrent ? null : (currentElig?.reason ?? null);

  const isPlaceEligible = (id: number): boolean => {
    const e = eligibilityMap[id];
    if (!e) return true;
    return e.nonComb.allowed || e.combo.allowed;
  };

  const canOpenSheet = isWithinRadius;

  const canDoAnyVisit =
    closestPlace != null &&
    ((eligNonComb?.allowed ?? true) ||
      ((eligCombo?.allowed ?? false) && comboPathValid));

  const buttonLabel = !closestPlace || !isWithinRadius
    ? 'Jsi moc daleko'
    : canDoAnyVisit
      ? 'Jsem tu!'
      : 'Návštěva není možná';

  useEffect(() => {
    if (sports.length > 0 && selectedSportId === undefined) {
      setSelectedSportId(sports[0].id);
    }
  }, [sports, selectedSportId]);

  useEffect(() => {
    const id = setInterval(() => setRefreshTick((t) => t + 1), 30000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    let locationSub: Location.LocationSubscription | null = null;
    let cancelled = false;

    const startTracking = async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted' || cancelled) return;

      locationSub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 5000, distanceInterval: 5 },
        (newLoc) => {
          if (cancelled) return;
          const next: GpsState = {
            lat: newLoc.coords.latitude,
            lng: newLoc.coords.longitude,
            accuracy: newLoc.coords.accuracy,
          };
          setGps(next);
        }
      );
    };

    startTracking();
    return () => {
      cancelled = true;
      if (locationSub) locationSub.remove();
    };
  }, []);

  useEffect(() => {
    if (!gps || places.length === 0) return;
    let minDistance = Infinity;
    let foundPlace: Place | null = null;

    for (const place of places) {
      if (!isPlaceEligible(place.id)) continue;
      const [placeLng, placeLat] = place.coordinates.coordinates;
      const distance = getDistanceInMeters(gps.lat, gps.lng, placeLat, placeLng);
      if (distance < minDistance) {
        minDistance = distance;
        foundPlace = place;
      }
    }

    if (foundPlace) setClosestPlace({ place: foundPlace, distance: minDistance });
  }, [gps, places, eligibilityMap]);

  useEffect(() => {
    if (!mapReady) return;
    mapRef.current?.updatePlaceStatus(placeStatus);
  }, [mapReady, placeStatus]);

  useEffect(() => {
    if (!mapReady || !gps) return;
    mapRef.current?.updateUserLocation(gps.lat, gps.lng, gps.accuracy);
  }, [mapReady, gps]);

  useEffect(() => {
    if (!mapReady) return;
    mapRef.current?.updateActivePlace(closestPlace?.place.id ?? null, isWithinRadius);
  }, [mapReady, closestPlace, isWithinRadius]);

  const handleReady = useCallback(() => {
    setMapReady(true);
  }, []);

  const handleVisitPress = () => {
    if (!isWithinRadius || !closestPlace || !canOpenSheet) return;
    if (!(eligNonComb?.allowed ?? true) && (eligCombo?.allowed ?? true) && !isCombination) {
      setIsCombination(true);
    }
    sheetRef.current?.expand();
  };

  const handleSaveVisit = async () => {
    if (!closestPlace || selectedSportId === undefined || !canVisitCurrent) return;
    const sport = sports.find((s) => s.id === selectedSportId);
    if (!sport) return;

    const reward = calculatedReward;
    const clientId = -Math.floor(Date.now() + Math.random() * 10000);
    const timestamp = new Date().toISOString();

    setIsSaving(true);
    sheetRef.current?.close();

    applyOptimisticVisit({
      clientId,
      place: closestPlace.place,
      sport,
      reward,
      is_combination: isCombination,
      timestamp,
    });

    try {
      const result = await saveVisit({
        place: closestPlace.place,
        sport,
        isCombination,
        timestamp,
        reward,
        clientId,
      });

      if (result.kind === 'offline') {
        Alert.alert(
          'Jsi offline',
          `Návštěva se uloží do paměti a odešle se, jakmile budeš zase na internetu. Zatím ti počítáme +${reward} bodů.`
        );
      } else {
        await refreshStats(true);
        if (result.data?.cheat_note) {
          Alert.alert('Pozor', `${result.data.cheat_note} Odměna byla přepočítána na +${result.data.reward} bodů.`);
        } else {
          Alert.alert('Úspěch!', `Získáváš +${result.data?.reward ?? reward} bodů!`);
        }
      }
    } catch (err: any) {
      revertOptimisticVisit(clientId);
      Alert.alert('Návštěva byla zamítnuta', err?.message || 'Zkus to prosím později.');
    } finally {
      setIsSaving(false);
      setIsCombination(false);
    }
  };

  const isLoading = loadingPlaces || loadingSports || loadingStats;

  return (
    <View style={styles.container}>
      {isLoading && places.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#059669" />
        </View>
      ) : (
        <>
          <View style={styles.mapWrapper}>
            <LeafletMapView
              ref={mapRef}
              places={places}
              defaultLat={DEFAULT_LAT}
              defaultLng={DEFAULT_LNG}
              visitRadiusMeters={VISIT_RADIUS}
              onReady={handleReady}
            />
          </View>

          <View style={styles.topBar}>
            <Text style={styles.topBarLabel}>Sport</Text>
            <SportChips sports={sports} selectedId={selectedSportId} onSelect={setSelectedSportId} />
          </View>

          <View pointerEvents="box-none" style={styles.bottomArea}>
            <TouchableOpacity
              style={[
                styles.visitButton,
                isWithinRadius && canDoAnyVisit
                  ? styles.visitButtonActive
                  : styles.visitButtonInactive,
              ]}
              disabled={!canOpenSheet}
              onPress={handleVisitPress}
            >
              <Text style={styles.visitButtonText} numberOfLines={1}>
                {buttonLabel}
              </Text>
            </TouchableOpacity>
            {closestPlace && (
              <View style={styles.targetInfo}>
                <Text style={styles.targetName} numberOfLines={1}>
                  Cíl: {closestPlace.place.name}
                </Text>
                <Text style={styles.targetDistance}>
                  {Math.round(closestPlace.distance)} m
                </Text>
              </View>
            )}
            {isWithinRadius && !canVisitCurrent && (
              <Text style={styles.targetBlockHint}>{blockReason}</Text>
            )}
          </View>

          <View pointerEvents="box-none" style={styles.sheetLayer}>
            <VisitSheet
              ref={sheetRef}
              place={closestPlace?.place ?? null}
              distance={closestPlace?.distance ?? null}
              sports={sports}
              selectedSportId={selectedSportId}
              onSelectSport={setSelectedSportId}
              lastVisit={lastVisit}
              showCombination={!!lastVisit}
              isCombination={isCombination}
              onToggleCombination={setIsCombination}
              allowed={canVisitCurrent}
              blockReason={blockReason}
              comboNote={comboNote}
              reward={calculatedReward}
              isSaving={isSaving}
              onSave={handleSaveVisit}
              onChange={() => {}}
            />
          </View>
        </>
      )}

      {error && (
        <View style={styles.errorBanner}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f1f5f9',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  topBar: {
    position: 'absolute',
    top: 12,
    left: 16,
    right: 16,
    zIndex: 5,
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 14,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 5,
  },
  topBarLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: '#64748b',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 6,
    marginLeft: 4,
  },
  bottomArea: {
    position: 'absolute',
    left: 20,
    right: 20,
    bottom: 26,
    zIndex: 8,
    alignItems: 'center',
  },
  visitButton: {
    height: 64,
    minWidth: 240,
    maxWidth: '94%',
    paddingHorizontal: 28,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.22,
    shadowRadius: 8,
    elevation: 9,
  },
  visitButtonActive: {
    backgroundColor: '#10b981',
  },
  visitButtonInactive: {
    backgroundColor: '#94a3b8',
  },
  visitButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '900',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    textAlign: 'center',
    includeFontPadding: false,
  },
  targetInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    backgroundColor: 'rgba(255,255,255,0.94)',
    borderRadius: 999,
    paddingLeft: 16,
    paddingRight: 6,
    paddingVertical: 6,
    gap: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  targetName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0f172a',
    maxWidth: 190,
  },
  targetDistance: {
    fontSize: 12,
    fontWeight: '800',
    color: '#047857',
    backgroundColor: '#d1fae5',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    overflow: 'hidden',
  },
  targetBlockHint: {
    marginTop: 10,
    maxWidth: '92%',
    backgroundColor: 'rgba(254,242,242,0.97)',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 7,
    color: '#b91c1c',
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  sheetLayer: {
    ...StyleSheet.absoluteFill,
    zIndex: 50,
  },
  errorBanner: {
    position: 'absolute',
    top: 110,
    left: 20,
    right: 20,
    backgroundColor: '#ef4444',
    padding: 10,
    borderRadius: 10,
  },
  errorText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: '700',
  },
});