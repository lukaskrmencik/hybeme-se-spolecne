import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, ActivityIndicator, Alert, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import { useUserStats } from '../../../context/UserStatsContext';
import { useAuth } from '../../../context/AuthContext';
import { apiFetch, getBaseUrl } from '../../../services/api';
import { getToken } from '../../../services/storage';
import { Avatar } from '../../../components/Avatar';
import { colors, radius, shadows, typography } from '../../../utils/theme';

const ROLE_LABEL: Record<string, string> = {
    admin: 'Administrátor',
    user: 'Uživatel',
};

export default function AccountScreen() {
    const { profile, refreshStats, loading } = useUserStats();
    const { logout } = useAuth();
    const router = useRouter();

    const [editing, setEditing] = useState(false);
    const [name, setName] = useState('');
    const [saving, setSaving] = useState(false);
    const [uploadingAvatar, setUploadingAvatar] = useState(false);
    const [deleting, setDeleting] = useState(false);

    if (loading && !profile) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    if (!profile) return null;

    const visits = profile.visitsCombinations ?? [];
    const comboCount = visits.filter((v) => v.is_combination).length;
    const role = ROLE_LABEL[profile.role] ?? profile.role;

    const startEdit = () => {
        setName(profile.name);
        setEditing(true);
    };

    const saveName = async () => {
        const trimmed = name.trim();
        if (!trimmed) return;
        setSaving(true);
        try {
            await apiFetch(`users/${profile.id}`, {
                method: 'PATCH',
                body: JSON.stringify({ name: trimmed }),
            });
            await refreshStats(true);
            setEditing(false);
        } catch (err: any) {
            Alert.alert('Nepovedlo se', err?.error_message || 'Jméno se nepodařilo uložit.');
        } finally {
            setSaving(false);
        }
    };

    const pickAvatar = async () => {
        if (Platform.OS !== 'web') {
            const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (!permission.granted) {
                Alert.alert('Oprávnění', 'Bez přístupu k fotkám nelze avatar změnit.');
                return;
            }
        }

        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ['images'],
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.7,
        });

        if (result.canceled || !result.assets?.length) return;

        const asset = result.assets[0];
        const uri = asset.uri;
        const extMatch = /\.(\w+)$/.exec(uri);
        const name =
            asset.file?.name ||
            uri.split('/').pop() ||
            `avatar.${extMatch?.[1] || 'jpg'}`;
        const type = asset.mimeType ?? `image/${extMatch?.[1] || 'jpeg'}`;

        setUploadingAvatar(true);
        try {
            const token = await getToken();
            if (!token) return;

            const form = new FormData();
            if (Platform.OS === 'web' && asset.file) {
                form.append('avatar', asset.file, name);
            } else if (Platform.OS === 'web') {
                const blob = await (await fetch(asset.uri)).blob();
                form.append('avatar', blob, name);
            } else {
                form.append('avatar', { uri, name, type } as any);
            }

            const res = await fetch(`${getBaseUrl()}users/${profile.id}/avatar`, {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: form,
            });

            if (!res.ok) {
                let msg = 'Avatar se nepodařilo nahrát.';
                try {
                    const data = await res.json();
                    msg = data?.error_message || msg;
                } catch {}
                throw new Error(msg);
            }

            await refreshStats(true);
        } catch (err: any) {
            Alert.alert('Nepovedlo se', err?.message || 'Avatar se nepodařilo nahrát.');
        } finally {
            setUploadingAvatar(false);
        }
    };

    const confirmDelete = () => {
        Alert.alert(
            'Smazat účet?',
            'Tvé body, návštěvy i účet budou nenávratně smazány. Tuto akci nelze vrátit zpět.',
            [
                { text: 'Zrušit', style: 'cancel' },
                {
                    text: 'Smazat',
                    style: 'destructive',
                    onPress: async () => {
                        setDeleting(true);
                        try {
                            await apiFetch(`users/${profile.id}`, { method: 'DELETE' });
                            await logout();
                            router.replace('/login');
                        } catch (err: any) {
                            Alert.alert('Nepovedlo se', err?.error_message || 'Účet se nepodařilo smazat.');
                            setDeleting(false);
                        }
                    },
                },
            ]
        );
    };

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.content}>
            <View style={styles.profileCard}>
                {uploadingAvatar ? (
                    <View style={styles.avatarLoading}>
                        <ActivityIndicator color={colors.primary} />
                    </View>
                ) : (
                    <TouchableOpacity onPress={pickAvatar} activeOpacity={0.85}>
                        <Avatar name={profile.name} url={profile.avatar_url} size={84} />
                        <View style={styles.avatarEdit}>
                            <Ionicons name="camera" size={14} color="#fff" />
                        </View>
                    </TouchableOpacity>
                )}

                {editing ? (
                    <View style={styles.editRow}>
                        <TextInput
                            style={styles.nameInput}
                            value={name}
                            onChangeText={setName}
                            autoFocus
                            returnKeyType="done"
                            onSubmitEditing={saveName}
                        />
                        <TouchableOpacity style={styles.saveNameButton} onPress={saveName} disabled={saving}>
                            {saving ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Ionicons name="checkmark" size={20} color="#fff" />
                            )}
                        </TouchableOpacity>
                    </View>
                ) : (
                    <View style={styles.nameRow}>
                        <Text style={styles.name}>{profile.name}</Text>
                        <TouchableOpacity onPress={startEdit} hitSlop={10}>
                            <Ionicons name="pencil" size={18} color={colors.muted} />
                        </TouchableOpacity>
                    </View>
                )}

                <Text style={styles.email}>{profile.email}</Text>
                <View style={styles.roleChip}>
                    <Ionicons name={profile.role === 'admin' ? 'shield-checkmark' : 'person'} size={13} color={colors.primaryDark} />
                    <Text style={styles.roleChipText}>{role}</Text>
                </View>
            </View>

            <View style={styles.statsGrid}>
                <View style={styles.statCard}>
                    <View style={[styles.statIcon, styles.statIconPrimary]}>
                        <Ionicons name="star" size={20} color={colors.accentText} />
                    </View>
                    <Text style={styles.statValue}>{profile.totalPoints}</Text>
                    <Text style={styles.statLabel}>bodů</Text>
                </View>
                <View style={styles.statCard}>
                    <View style={[styles.statIcon, styles.statIconGreen]}>
                        <Ionicons name="footsteps" size={20} color={colors.primaryDark} />
                    </View>
                    <Text style={styles.statValue}>{visits.length}</Text>
                    <Text style={styles.statLabel}>návštěv</Text>
                </View>
                <View style={styles.statCard}>
                    <View style={[styles.statIcon, styles.statIconBlue]}>
                        <Ionicons name="git-merge" size={20} color="#1d4ed8" />
                    </View>
                    <Text style={styles.statValue}>{comboCount}</Text>
                    <Text style={styles.statLabel}>kombinací</Text>
                </View>
            </View>

            <Text style={styles.sectionTitle}>O aplikaci</Text>
            <View style={styles.infoCard}>
                <View style={styles.infoRow}>
                    <View style={styles.infoIcon}>
                        <Ionicons name="information-circle-outline" size={22} color={colors.primaryDark} />
                    </View>
                    <View style={styles.infoBody}>
                        <Text style={styles.infoTitle}>Hýbeme se společně</Text>
                        <Text style={styles.infoText}>
                            Navštěvuj místa, sbírej body a kombinováním návštěv získávej bonusové odměny.
                        </Text>
                    </View>
                </View>
            </View>

            <TouchableOpacity style={styles.logoutButton} onPress={logout} disabled={deleting}>
                <Ionicons name="log-out-outline" size={20} color={colors.dangerText} />
                <Text style={styles.logoutText}>Odhlásit se</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.deleteButton} onPress={confirmDelete} disabled={deleting}>
                {deleting ? (
                    <ActivityIndicator size="small" color={colors.danger} />
                ) : (
                    <Ionicons name="trash-outline" size={18} color={colors.danger} />
                )}
                <Text style={styles.deleteText}>Smazat účet</Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    content: { padding: 16, paddingBottom: 40 },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background },
    profileCard: {
        backgroundColor: colors.surface,
        borderRadius: radius.lg,
        alignItems: 'center',
        paddingVertical: 26,
        paddingHorizontal: 20,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.card,
    },
    avatarLoading: {
        width: 84,
        height: 84,
        borderRadius: 42,
        backgroundColor: colors.primaryBg,
        alignItems: 'center',
        justifyContent: 'center',
    },
    avatarEdit: {
        position: 'absolute',
        right: 0,
        bottom: 0,
        width: 26,
        height: 26,
        borderRadius: 13,
        backgroundColor: colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 2,
        borderColor: colors.surface,
    },
    nameRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14 },
    name: { fontSize: 22, fontWeight: '900', color: colors.text },
    editRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
    nameInput: {
        borderWidth: 1,
        borderColor: colors.border,
        borderRadius: radius.sm + 2,
        paddingHorizontal: 14,
        paddingVertical: 8,
        fontSize: 17,
        fontWeight: '800',
        color: colors.text,
        minWidth: 180,
        backgroundColor: colors.background,
    },
    saveNameButton: {
        width: 42,
        height: 42,
        borderRadius: 21,
        backgroundColor: colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
    },
    email: { fontSize: 14, color: colors.muted, marginTop: 4 },
    roleChip: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        marginTop: 10,
        backgroundColor: colors.primaryBg,
        paddingHorizontal: 12,
        paddingVertical: 5,
        borderRadius: radius.full,
    },
    roleChipText: { color: colors.primaryDark, fontWeight: '800', fontSize: 13 },
    statsGrid: { flexDirection: 'row', gap: 10, marginTop: 16, marginBottom: 22 },
    statCard: {
        flex: 1,
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        alignItems: 'center',
        paddingVertical: 16,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.card,
    },
    statIcon: {
        width: 40,
        height: 40,
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 8,
    },
    statIconPrimary: { backgroundColor: colors.accentBg },
    statIconGreen: { backgroundColor: colors.primaryBg },
    statIconBlue: { backgroundColor: '#eff6ff' },
    statValue: { fontSize: 22, fontWeight: '900', color: colors.text },
    statLabel: { fontSize: 12, color: colors.muted, fontWeight: '700', marginTop: 2 },
    sectionTitle: { ...typography.sectionTitle, marginBottom: 10 },
    infoCard: {
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        padding: 16,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.card,
    },
    infoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    infoIcon: {
        width: 44,
        height: 44,
        borderRadius: radius.sm + 2,
        backgroundColor: colors.primaryBg,
        alignItems: 'center',
        justifyContent: 'center',
    },
    infoBody: { flex: 1 },
    infoTitle: { fontSize: 15, fontWeight: '800', color: colors.text },
    infoText: { fontSize: 13, color: colors.muted, marginTop: 3, lineHeight: 18 },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        backgroundColor: colors.dangerBg,
        borderRadius: radius.md,
        paddingVertical: 15,
        marginTop: 20,
        borderWidth: 1,
        borderColor: '#fecaca',
    },
    logoutText: { color: colors.dangerText, fontWeight: '800', fontSize: 16 },
    deleteButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        paddingVertical: 14,
        marginTop: 4,
    },
    deleteText: { color: colors.danger, fontWeight: '700', fontSize: 14 },
});