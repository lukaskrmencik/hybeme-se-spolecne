import React, { useState, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    ActivityIndicator,
    RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import { useUserStats } from '../../../context/UserStatsContext';
import { getQueuedVisits } from '../../../services/offlineQueue';
import { QueuedVisit } from '../../../types/visit';
import { formatVisitTime, parseVisitTime } from '../../../utils/dates';
import { colors, radius, shadows, typography } from '../../../utils/theme';

type Visit = NonNullable<ReturnType<typeof useUserStats>['profile']>['visitsCombinations'][number];

export default function VisitsScreen() {
    const { profile, pendingCount, refreshStats, flushNow, loading } = useUserStats();
    const [queued, setQueued] = useState<QueuedVisit[]>([]);
    const [syncing, setSyncing] = useState(false);
    const [refreshing, setRefreshing] = useState(false);

    const loadQueue = useCallback(async () => {
        setQueued(await getQueuedVisits());
    }, []);

    useFocusEffect(
        useCallback(() => {
            loadQueue();
        }, [loadQueue])
    );

    const handleSync = async () => {
        setSyncing(true);
        try {
            await flushNow();
        } finally {
            await loadQueue();
            await refreshStats(true);
            setSyncing(false);
        }
    };

    const handleRefresh = async () => {
        setRefreshing(true);
        try {
            await Promise.all([loadQueue(), refreshStats(true)]);
        } finally {
            setRefreshing(false);
        }
    };

    const visits: Visit[] = profile?.visitsCombinations ?? [];
    const sortedVisits = [...visits].sort(
        (a, b) => parseVisitTime(b.timestamp) - parseVisitTime(a.timestamp)
    );
    const totalVisits = visits.length;
    const comboCount = visits.filter((v) => v.is_combination).length;
    const points = profile?.totalPoints ?? 0;

    const renderQueued = ({ item }: { item: QueuedVisit }) => (
        <View style={styles.queuedItem}>
            <View style={styles.queuedIcon}>
                <Ionicons name="cloud-offline-outline" size={20} color={colors.accentText} />
            </View>
            <View style={styles.itemBody}>
                <Text style={styles.itemTitle} numberOfLines={1}>
                    {item.place_name || `Místo #${item.place_id}`}
                </Text>
                <Text style={styles.itemMeta}>
                    {item.sport_name ? `${item.sport_name} · ` : ''}
                    {formatVisitTime(item.timestamp)}
                </Text>
            </View>
            <Text style={styles.itemReward}>+{item.reward}</Text>
        </View>
    );

    const renderVisit = ({ item }: { item: Visit }) => {
        const namedPlace = item.place?.name || `Místo #${item.place_id}`;
        const comboLevel = item.combination_order != null ? item.combination_order + 1 : 0;

        return (
            <View style={styles.visitItem}>
                <View style={styles.visitIcon}>
                    <Ionicons name="location" size={20} color={colors.primaryDark} />
                </View>
                <View style={styles.itemBody}>
                    <Text style={styles.itemTitle} numberOfLines={1}>
                        {namedPlace}
                    </Text>
                    <Text style={styles.itemMeta} numberOfLines={1}>
                        {item.sport?.name ?? 'Sport'} · {formatVisitTime(item.timestamp)}
                    </Text>
                    {item.is_combination && (
                        <View style={styles.comboTagRow}>
                            <Ionicons name="git-merge-outline" size={12} color={colors.primaryDark} />
                            <Text style={styles.comboTag}>
                                kombinace ×{comboLevel}
                            </Text>
                        </View>
                    )}
                </View>
                <View style={styles.rewardWrap}>
                    <Text style={styles.itemReward}>+{item.reward}</Text>
                    <Text style={styles.rewardUnit}>bodů</Text>
                </View>
            </View>
        );
    };

    if (loading && !profile) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    return (
        <FlatList
            style={styles.container}
            contentContainerStyle={styles.content}
            data={sortedVisits}
            keyExtractor={(item, index) => `${item.id}-${index}`}
            refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.primary} />
            }
            ListHeaderComponent={
                <>
                    <View style={styles.pointsCard}>
                        <Ionicons name="star" size={26} color="#a7f3d0" style={styles.pointsIcon} />
                        <Text style={styles.pointsLabel}>Celkem nasbíráno</Text>
                        <Text style={styles.pointsValue}>{points}</Text>
                        <Text style={styles.pointsUnit}>bodů</Text>
                        <View style={styles.statsRow}>
                            <View style={styles.statChip}>
                                <Text style={styles.statValue}>{totalVisits}</Text>
                                <Text style={styles.statLabel}>návštěv</Text>
                            </View>
                            <View style={[styles.statChip, styles.statChipOutline]}>
                                <Text style={styles.statValue}>{comboCount}</Text>
                                <Text style={styles.statLabel}>kombinací</Text>
                            </View>
                        </View>
                    </View>

                    <View style={styles.syncCard}>
                        <View style={styles.syncIcon}>
                            <Ionicons
                                name={pendingCount > 0 ? 'cloud-offline-outline' : 'cloud-done-outline'}
                                size={22}
                                color={pendingCount > 0 ? colors.accentText : colors.primaryDark}
                            />
                        </View>
                        <View style={styles.syncBody}>
                            <Text style={styles.syncTitle}>
                                {pendingCount > 0
                                    ? `${pendingCount} návštěv(á) čeká na odeslání`
                                    : 'Vše je synchronizováno'}
                            </Text>
                            <Text style={styles.syncMeta}>
                                {pendingCount > 0
                                    ? 'Nahraje se automaticky, jakmile budeš mít signál.'
                                    : 'Offline fronta je prázdná.'}
                            </Text>
                        </View>
                        <TouchableOpacity
                            style={[styles.syncButton, syncing && styles.syncButtonDisabled]}
                            onPress={handleSync}
                            disabled={syncing || pendingCount === 0}
                        >
                            {syncing ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Text style={styles.syncButtonText}>Odeslat</Text>
                            )}
                        </TouchableOpacity>
                    </View>

                    {queued.length > 0 && (
                        <>
                            <Text style={styles.sectionTitle}>Čeká na odeslání</Text>
                            <FlatList
                                data={queued}
                                keyExtractor={(item) => item.id}
                                renderItem={renderQueued}
                                scrollEnabled={false}
                                style={styles.list}
                            />
                        </>
                    )}

                    <Text style={styles.sectionTitle}>Historie návštěv</Text>
                </>
            }
            renderItem={renderVisit}
            ListEmptyComponent={
                <View style={styles.emptyBox}>
                    <Ionicons name="footsteps-outline" size={40} color={colors.inactive} />
                    <Text style={styles.emptyText}>Zatím žádné návštěvy.</Text>
                    <Text style={styles.emptyHint}>Zkus navštívit nějaké místo na mapě.</Text>
                </View>
            }
        />
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    content: { padding: 16, paddingBottom: 40 },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background },
    pointsCard: {
        backgroundColor: colors.primary,
        borderRadius: radius.lg,
        alignItems: 'center',
        paddingVertical: 26,
        marginBottom: 16,
        ...shadows.card,
    },
    pointsIcon: { marginBottom: 2 },
    pointsLabel: { color: '#a7f3d0', fontSize: 13, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
    pointsValue: { color: '#fff', fontSize: 52, fontWeight: '900', marginTop: 2, lineHeight: 56 },
    pointsUnit: { color: '#a7f3d0', fontSize: 13, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
    statsRow: { flexDirection: 'row', gap: 10, marginTop: 14 },
    statChip: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: 'rgba(255,255,255,0.16)',
        paddingHorizontal: 14,
        paddingVertical: 7,
        borderRadius: radius.full,
    },
    statChipOutline: {
        backgroundColor: 'rgba(255,255,255,0.06)',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.28)',
    },
    statValue: { color: '#fff', fontSize: 15, fontWeight: '900' },
    statLabel: { color: '#a7f3d0', fontSize: 13, fontWeight: '700' },
    syncCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        padding: 14,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.card,
    },
    syncIcon: {
        width: 42,
        height: 42,
        borderRadius: 21,
        backgroundColor: colors.primaryBg,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 12,
    },
    syncBody: { flex: 1 },
    syncTitle: { fontSize: 15, fontWeight: '800', color: colors.text },
    syncMeta: { fontSize: 13, color: colors.muted, marginTop: 3 },
    syncButton: {
        backgroundColor: colors.primary,
        paddingHorizontal: 16,
        paddingVertical: 10,
        borderRadius: radius.sm + 4,
        ...shadows.button,
    },
    syncButtonDisabled: { opacity: 0.6 },
    syncButtonText: { color: '#fff', fontWeight: '800', fontSize: 14 },
    sectionTitle: {
        ...typography.sectionTitle,
        marginBottom: 10,
        marginTop: 6,
    },
    list: { marginBottom: 8 },
    queuedItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.accentBg,
        borderRadius: radius.md,
        padding: 14,
        borderWidth: 1,
        borderColor: '#fde68a',
        marginBottom: 8,
    },
    queuedIcon: {
        width: 38,
        height: 38,
        borderRadius: 19,
        backgroundColor: '#fde68a',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 12,
    },
    visitItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        padding: 14,
        borderWidth: 1,
        borderColor: colors.border,
        marginBottom: 8,
        ...shadows.card,
    },
    visitIcon: {
        width: 40,
        height: 40,
        borderRadius: radius.full,
        backgroundColor: colors.primaryBg,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 12,
    },
    itemBody: { flex: 1, marginRight: 8 },
    itemTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
    itemMeta: { fontSize: 12, color: colors.muted, marginTop: 2 },
    comboTagRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 5 },
    comboTag: {
        color: colors.primaryDark,
        fontSize: 12,
        fontWeight: '800',
        backgroundColor: colors.primaryLight,
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: radius.sm - 2,
        overflow: 'hidden',
    },
    rewardWrap: { alignItems: 'flex-end' },
    itemReward: { fontSize: 17, fontWeight: '900', color: colors.primary },
    rewardUnit: { fontSize: 11, color: colors.muted, fontWeight: '700', textTransform: 'uppercase' },
    emptyBox: {
        backgroundColor: colors.surface,
        borderRadius: radius.md,
        padding: 32,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: colors.border,
        gap: 6,
    },
    emptyText: { color: colors.text, fontWeight: '800', fontSize: 16, marginTop: 4 },
    emptyHint: { color: colors.muted, fontWeight: '600', textAlign: 'center' },
});