import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { colors, radius, shadows, typography } from '../../utils/theme';

export default function LoginScreen() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');
    const [loading, setLoading] = useState(false);

    const { login } = useAuth();
    const router = useRouter();

    const handleLogin = async () => {
        setErrorMsg('');
        setLoading(true);

        try {
            await login({ email, password });
        } catch (err: any) {
            setErrorMsg(err.error_message || 'Přihlášení se nezdařilo.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
                <View style={styles.logoWrap}>
                    <Ionicons name="walk" size={52} color="#fff" />
                </View>
                <Text style={styles.title}>Hýbeme se společně</Text>
                <Text style={styles.subtitle}>Přihlas se a sbírej body za návštěvy</Text>

                {!!errorMsg && (
                    <View style={styles.errorBox}>
                        <Ionicons name="alert-circle" size={18} color={colors.dangerText} />
                        <Text style={styles.errorText}>{errorMsg}</Text>
                    </View>
                )}

                <View style={styles.card}>
                    <View style={styles.field}>
                        <Ionicons name="mail-outline" size={20} color={colors.muted} />
                        <TextInput
                            style={styles.input}
                            placeholder="E-mail"
                            placeholderTextColor={colors.inactive}
                            value={email}
                            onChangeText={setEmail}
                            autoCapitalize="none"
                            keyboardType="email-address"
                        />
                    </View>

                    <View style={styles.field}>
                        <Ionicons name="lock-closed-outline" size={20} color={colors.muted} />
                        <TextInput
                            style={styles.input}
                            placeholder="Heslo"
                            placeholderTextColor={colors.inactive}
                            value={password}
                            onChangeText={setPassword}
                            secureTextEntry={!showPassword}
                        />
                        <TouchableOpacity onPress={() => setShowPassword((v) => !v)} hitSlop={10}>
                            <Ionicons
                                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                                size={20}
                                color={colors.muted}
                            />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity style={styles.button} onPress={handleLogin} disabled={loading}>
                        {loading ? (
                            <ActivityIndicator color="#fff" />
                        ) : (
                            <Text style={styles.buttonText}>Přihlásit se</Text>
                        )}
                    </TouchableOpacity>
                </View>

                <TouchableOpacity onPress={() => router.push('/register')}>
                    <Text style={styles.linkText}>Nemáš účet? Zaregistruj se</Text>
                </TouchableOpacity>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.primaryBg },
    scroll: { flexGrow: 1, justifyContent: 'center', padding: 24 },
    logoWrap: {
        alignSelf: 'center',
        width: 96,
        height: 96,
        borderRadius: 48,
        backgroundColor: colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 18,
        ...shadows.button,
    },
    title: { fontSize: 26, fontWeight: '900', textAlign: 'center', color: colors.primaryDark },
    subtitle: { fontSize: 15, textAlign: 'center', color: colors.muted, marginTop: 4, marginBottom: 24 },
    card: {
        backgroundColor: colors.surface,
        borderRadius: radius.lg,
        padding: 20,
        ...shadows.card,
    },
    field: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        borderWidth: 1,
        borderColor: colors.border,
        borderRadius: radius.md,
        paddingHorizontal: 14,
        height: 52,
        marginBottom: 14,
        backgroundColor: colors.surface,
    },
    input: { flex: 1, fontSize: 16, color: colors.text },
    button: {
        height: 52,
        backgroundColor: colors.primary,
        borderRadius: radius.md,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 6,
        ...shadows.button,
    },
    buttonText: { color: '#fff', fontSize: 17, fontWeight: '800' },
    errorBox: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        backgroundColor: colors.dangerBg,
        borderRadius: radius.md,
        padding: 12,
        marginBottom: 14,
        borderWidth: 1,
        borderColor: '#fecaca',
    },
    errorText: { color: colors.dangerText, fontSize: 13, fontWeight: '700', flex: 1 },
    linkText: { color: colors.primaryDark, textAlign: 'center', fontSize: 14, fontWeight: '700', marginTop: 20 },
});